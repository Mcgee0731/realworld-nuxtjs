const middleware = {}

middleware['notuserlogin'] = require('..\\middleware\\notuserlogin.js')
middleware['notuserlogin'] = middleware['notuserlogin'].default || middleware['notuserlogin']

middleware['userlogin'] = require('..\\middleware\\userlogin.js')
middleware['userlogin'] = middleware['userlogin'].default || middleware['userlogin']

export default middleware
